package com.timbuchalka;

public class Main {

    public static void main(String[] args)
    {

            Todo todo=new Todo("teszt","2023.04.23");

            System.out.println(todo.getTodoDescription());
            System.out.println(todo.getTodoAddDate());
            System.out.println(todo.isTodoCompleted());
            System.out.println(todo.getTodoDate());
            System.out.println(todo.getTodoImportanceRating());



    }
}
