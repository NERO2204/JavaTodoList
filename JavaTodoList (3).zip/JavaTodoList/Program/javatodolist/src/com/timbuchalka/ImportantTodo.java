package com.timbuchalka;

public class ImportantTodo extends Todo
{
    private int importanceNumber;

    public ImportantTodo(String todoDescription, String todoAddDate, boolean isTodoCompleted, String todoDate, int importanceNumber) {
        super(todoDescription, todoAddDate, isTodoCompleted, todoDate);
        this.importanceNumber = importanceNumber;
    }

    public int getImportanceNumber() {
        return importanceNumber;
    }

    @Override
    public String toString() {
        return "ImportantTodo{" +
                "importanceNumber=" + importanceNumber +
                "} " + super.toString();
    }
}
