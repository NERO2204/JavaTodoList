package com.timbuchalka;

public class Todo
{
    private String todoDescription;
    private String todoAddDate;
    private boolean isTodoCompleted;
    private String todoDate;




    public Todo(String todoDescription, String todoAddDate, boolean isTodoCompleted, String todoDate) {
        this.todoDescription = todoDescription;
        this.todoAddDate = todoAddDate;
        this.isTodoCompleted = isTodoCompleted;
        this.todoDate = todoDate;

    }

    public Todo(String todoDescription, String todoAddDate)
    {
        this(todoDescription,todoAddDate,false,null);
        this.todoDescription = todoDescription;
        this.todoAddDate = todoAddDate;
    }


    public String getTodoDescription() {
        return todoDescription;
    }

    public void setTodoDescription(String todoDescription) {
        this.todoDescription = todoDescription;
    }

    public String getTodoDate() {
        return todoDate;
    }

    public void setTodoDate(String todoDate) {
        this.todoDate = todoDate;
    }

    public String getTodoAddDate() {
        return todoAddDate;
    }

    public void setTodoAddDate(String todoAddDate) {
        this.todoAddDate = todoAddDate;
    }


    public boolean isTodoCompleted()
    {
        return isTodoCompleted;
    }

   
    public void completeTodo()
    {
        this.isTodoCompleted=true;

    }

    @Override
    public String toString() {
        return "ImportantTodo{" +
                "todoDescription='" + todoDescription + '\'' +
                ", todoAddDate='" + todoAddDate + '\'' +
                ", isTodoCompleted=" + isTodoCompleted +
                ", todoDate='" + todoDate + '\'' +
                '}';
    }
}
