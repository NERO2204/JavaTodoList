package com.timbuchalka;

public class Todo
{
    private String todoDescription;
    private String todoAddDate;
    private boolean isTodoCompleted;
    private String todoDate;
    private int todoImportanceRating;



    public Todo(String todoDescription, String todoAddDate, boolean isTodoCompleted, String todoDate, int todoImportanceRating) {
        this.todoDescription = todoDescription;
        this.todoAddDate = todoAddDate;
        this.isTodoCompleted = isTodoCompleted;
        this.todoDate = todoDate;
        this.todoImportanceRating = todoImportanceRating;
    }

    public Todo(String todoDescription, String todoAddDate)
    {
        this(todoDescription,todoAddDate,false,null,0);
        this.todoDescription = todoDescription;
        this.todoAddDate = todoAddDate;
    }


    public String getTodoDescription() {
        return todoDescription;
    }

    public void setTodoDescription(String todoDescription) {
        this.todoDescription = todoDescription;
    }

    public String getTodoDate() {
        return todoDate;
    }

    public void setTodoDate(String todoDate) {
        this.todoDate = todoDate;
    }

    public String getTodoAddDate() {
        return todoAddDate;
    }

    public void setTodoAddDate(String todoAddDate) {
        this.todoAddDate = todoAddDate;
    }

    public int getTodoImportanceRating() {
        return todoImportanceRating;
    }

    public void setTodoImportanceRating(int todoImportanceRating) {
        this.todoImportanceRating = todoImportanceRating;
    }

    public boolean isTodoCompleted()
    {
        return isTodoCompleted;
    }

   
    public void completeTodo()
    {
        this.isTodoCompleted=true;

    }


}
