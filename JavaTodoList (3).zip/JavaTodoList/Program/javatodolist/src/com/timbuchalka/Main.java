package com.timbuchalka;

public class Main {

    public static void main(String[] args)
    {

        ImportantTodo todo=new ImportantTodo("test","2023",false,"2023.04.02",10);
        System.out.println(todo.toString());


    }
}
